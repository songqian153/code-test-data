package program;

import java.util.Scanner;

public class p5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  System.out.println("���������֣�");
		  Scanner scanner = new Scanner(System.in);
		  int parm=scanner.nextInt();
		  
		  System.out.print(parm+"=");
		  
		  for(int i=2;i<=parm;i++)
		  {
		    while(parm!=i)
		      {
		          if(parm%i==0)
		        { 
		            System.out.print(i+"*");
		            parm=parm/i;
		        }
		         else
		            break;
		    }
		  }
        System.out.print(parm);

	}

}
