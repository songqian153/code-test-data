package program;

public class p1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = new int[3];
		char[] b = new char[]{'a','b','c'};
		for(int i=0;i<3;i++){
		a[i] = i+1;
		}
		for(int i=0;i<b.length;i++){
		if(i==2){
		continue;
		}
		System.out.println(a[i]+":"+b[i]);
		}

	}

}
