package program;

public class p2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k;
		for(i=1;i<=9;i++)
			for(j=0;j<=9;j++)
				for(k=0;k<=9;k++)
					if(i*i*i+j*j*j+k*k*k==i*100+j*10+k)
						System.out.println(i*100+j*10+k);


	}

}
