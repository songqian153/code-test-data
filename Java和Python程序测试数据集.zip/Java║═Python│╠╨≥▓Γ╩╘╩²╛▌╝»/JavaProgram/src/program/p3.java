package program;

import java.util.Scanner;

public class p3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner cin = new Scanner(System.in);
		int n = cin.nextInt();
		int s = 1;
		for(int i=1;i<=n;i++){
			s*=i;
		}
		System.out.println(s);

	}

}
