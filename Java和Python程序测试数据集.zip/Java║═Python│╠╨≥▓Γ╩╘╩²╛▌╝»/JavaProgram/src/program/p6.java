package program;

import java.util.Scanner;

public class p6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		    int num=0,chartra=0,blak=0,other=0;  
	        Scanner  s=new Scanner(System.in);  
	        System.out.println("������ַ�����");  
	        String result=s.nextLine();  
	        char x[]=result.toCharArray();  
	        for(int i=0;i<x.length;i++){  
	           if(Character.isDigit(x[i])){  
	               num++;  
	           }else if(Character.isLetter(x[i])){  
	               chartra++;  
	           }else if(Character.isSpace(x[i])){  
	               blak++;  
	           }  
	           else{  
	               other++;  
	           }    
	        }  
	        System.out.println("���ֵĸ�����"+num);  
	        System.out.println("�ַ��ĸ�����"+chartra);  
	        System.out.println("�ո�ĸ�����"+blak);  
	        System.out.println("�����ĸ�����"+other);  

	}
}
