'''
Created on 2014-11-2
@author: Administrator
'''
class MyArray:
    def __init__(self):
        self.a = range(1,4)
        self.b = ['a','b','c']
    def getValue(self):
        tmp = {}
        for i in self.a:
            tmp[str(i)] = self.b[i-1]
        return tmp
a = MyArray()
x = a.getValue()
for i in x:
    if i == '3':continue
    print "%s:%s" % (i,x[i])