# coding=utf-8
import random
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


def get_random_teachers(ori, n):
    rand_num = []  # 存放随机数
    cnt = 0  # 已经生成随机数的个数
    while cnt < n:  # 产生n个随机数
        rand = random.randint(0, len(ori)-1)  # 在[ 0, len(ori)-1 ]中产生一个随机数（注意是闭区间）
        if rand not in rand_num:  # 随机数List中没有刚刚产生的随机数
            rand_num.append(rand)  # 则将该随机数加入到随机数List中
            cnt += 1  # 并且将随机数的个数+1
    res = []  # 待返回的教师列表
    for i in rand_num:  # 循环随机数List，如随机数List为[3,8,9]，则依次将ori中的第3,8,9个元素填充到res中
        res.append(ori[i])
    return res


teachers = ["白玉", "李雪梅", "张宇心", "秦子臻", "刘凯乐", "单新增", "曾新旺", "明途", "徐子墨", "魏温涛"]
selected = get_random_teachers(teachers, 3)
print str(teachers).decode('string_escape')
print str(selected).decode('string_escape')
