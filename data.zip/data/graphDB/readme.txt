Data File Format 
"t # N" means the Nth graph,
"v M L" means that the Mth vertex in this graph has label L,
"e P Q L" means that there is an edge connecting the Pth vertex with the Qth vertex. The edge has label L.

Each data file or query file end with "t # -1".
